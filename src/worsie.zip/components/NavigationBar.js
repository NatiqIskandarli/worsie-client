'use client';
import React from 'react';
import { Layout, Button, Avatar } from 'antd';
import Link from 'next/link';
import '@/styles/NavigationBar.css';

const { Header } = Layout;

const NavigationBar = () => {
  return (
    <Header className="navigation-bar">
      <div className="navigation-links">
        <Link href="/" className="nav-link">Home</Link>
        <Link href="/dynamic-sheets" className="nav-link">Dynamic Sheets</Link>
        <Link href="/recordo" className="nav-link active">Recordo</Link>
        <Link href="/papercut" className="nav-link">Papercut</Link>
        <Link href="/notebook" className="nav-link">Notebook</Link>
      </div>
      <div className="navigation-actions">
        <Button type="default">Dark Mode</Button>
        <Button type="default">English</Button>
        <Button type="default">Notif</Button>
        <Avatar src="/profile.jpg" alt="User" />
      </div>
    </Header>
  );
};

export default NavigationBar;
