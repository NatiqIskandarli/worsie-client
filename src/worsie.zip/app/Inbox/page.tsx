'use client';
import InboxLayout from '@/layouts/InboxLayout';

const InboxPage = () => {
  return (
    <>
        <InboxLayout/>
    </>
  );
};

export default InboxPage;
