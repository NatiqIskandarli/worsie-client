'use client';
import MainLayout from '@/layouts/MainLayout';

const HomePage = () => {
  return (
    <>
        <MainLayout/>
    </>
  );
};

export default HomePage;
