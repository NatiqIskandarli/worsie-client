'use client';
import React, { useState, useEffect } from 'react';
import { Table, Button } from 'antd';
import { v4 as uuidv4 } from 'uuid';

const Approvals = ({ className }) => {
  const [approvals, setApprovals] = useState([]);

  useEffect(() => {
    const generatedApprovals = Array(10).fill().map(() => ({
      id: uuidv4(),
      name: 'John Smith',
      subject: 'Lorem',
      reason: 'Lorem Ipsum'
    }));
    setApprovals(generatedApprovals);
  }, []);

  const columns = [
    {
      title: 'Name',
      dataIndex: 'name',
      key: 'name',
    },
    {
      title: 'Subject',
      dataIndex: 'subject',
      key: 'subject',
    },
    {
      title: 'Reason',
      dataIndex: 'reason',
      key: 'reason',
    },
    {
      title: 'Actions',
      key: 'actions',
      render: (_, record) => (
        <div>
          <Button type="primary" style={{ marginRight: 8 }}>Approve</Button>
          <Button type="default" style={{ marginRight: 8 }}>Reassign</Button>
          <Button type="danger">Reject</Button>
        </div>
      ),
    },
  ];

  return (
    <div className={`bg-white p-4 rounded shadow-md ${className || ''}`}>
      <h4 className="text-gray-700 font-semibold mb-4">Approvals</h4>
      <Table 
        columns={columns} 
        dataSource={approvals} 
        rowKey="id" 
        pagination={false} 
      />
    </div>
  );
};

export default Approvals;