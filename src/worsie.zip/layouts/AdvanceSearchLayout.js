import React from 'react';
import { Card, Input, Row, Col, Select, DatePicker, Checkbox, Radio, Button } from 'antd';
import { SearchOutlined, UserOutlined, PlusOutlined, LeftCircleTwoTone } from '@ant-design/icons';
import { useRouter } from 'next/navigation';
import '@/styles/AdvanceSearch.css';

const { Option } = Select;
const { RangePicker } = DatePicker;

const AdvanceSearchPage = () => {
    const router = useRouter();
  return (
    <div className="advance-search-page">
      <Button className="back-button" icon={<LeftCircleTwoTone />} type="text" onClick={() => router.back()}>
        Back
      </Button>
      <h2 className="page-title">Advance Search</h2>

      <Input
        placeholder="Type Record name or description"
        prefix={<SearchOutlined />}
        className="search-input"
      />

      <Card className="toggle-options">
        <Row gutter={[16, 16]}>
          <Col><Checkbox>Strict match</Checkbox></Col>
          <Col><Checkbox defaultChecked>Allowed tolerance</Checkbox><span className="tolerance-count">2</span></Col>
          <Col><Checkbox>Search inside the records</Checkbox></Col>
          <Col><Checkbox defaultChecked>Has File</Checkbox></Col>
          <Col><Checkbox defaultChecked>Search Field</Checkbox></Col>
        </Row>

        <Row gutter={[16, 16]} className="radio-group">
          <Radio.Group>
            <Radio value="all">Search All</Radio>
            <Radio value="record">Search In Record</Radio>
            <Radio value="cabinet">Search in Cabinet</Radio>
            <Radio value="space">Search in Space</Radio>
          </Radio.Group>
        </Row>
      </Card>

      <Card className="search-criteria">
        <Row gutter={[16, 16]}>
          <Col span={12}>
            <label>Owner</label>
            <Select defaultValue="Olivia Rhye" className="criteria-select">
              <Option value="olivia">Olivia Rhye @olivia</Option>
              <Option value="john">John Doe @john</Option>
            </Select>
            <UserOutlined className="icon-user" />
          </Col>

          <Col span={12}>
            <label>File Type</label>
            <Select defaultValue="PDF" className="criteria-select">
              <Option value="pdf">PDF</Option>
              <Option value="doc">DOC</Option>
              <Option value="xlsx">XLSX</Option>
            </Select>
            <PlusOutlined className="icon-plus" />
          </Col>

          <Col span={12}>
            <label>Department</label>
            <Select defaultValue="Maintenance" className="criteria-select">
              <Option value="maintenance">Maintenance</Option>
              <Option value="hr">HR</Option>
              <Option value="it">IT</Option>
            </Select>
            <PlusOutlined className="icon-plus" />
          </Col>

          <Col span={12}>
            <label>Company</label>
            <Select defaultValue="Shell" className="criteria-select">
              <Option value="shell">Shell</Option>
              <Option value="microsoft">Microsoft</Option>
            </Select>
            <PlusOutlined className="icon-plus" />
          </Col>

          <Col span={12}>
            <label>Tags</label>
            <Select defaultValue="Rotating Equipment" className="criteria-select">
              <Option value="equipment">Rotating Equipment</Option>
              <Option value="stationary">Stationary</Option>
            </Select>
            <PlusOutlined className="icon-plus" />
          </Col>

          <Col span={12}>
            <label>Record Type</label>
            <Select defaultValue="Invoice" className="criteria-select">
              <Option value="invoice">Invoice</Option>
              <Option value="report">Report</Option>
            </Select>
            <PlusOutlined className="icon-plus" />
          </Col>

          <Col span={12}>
            <label>Uploaded Date</label>
            <RangePicker className="criteria-date-picker" />
          </Col>

          <Col span={12}>
            <label>Approval Date</label>
            <RangePicker className="criteria-date-picker" />
          </Col>

          <Col span={12}>
            <label>Creation Date</label>
            <RangePicker className="criteria-date-picker" />
          </Col>
        </Row>
      </Card>
    </div>
  );
};

export default AdvanceSearchPage;
