'use client';
import AdvanceSearchLayout from '@/layouts/AdvanceSearchLayout';

const AdvanceSearchPage = () => {
  return (
    <>
        <AdvanceSearchLayout/>
    </>
  );
};

export default AdvanceSearchPage;
