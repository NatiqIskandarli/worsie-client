'use client';
import React, { useState } from 'react';
import { Button } from 'antd';
import {
  HomeOutlined,
  InboxOutlined,
  TeamOutlined,
  SettingOutlined,
  StarOutlined,
  SearchOutlined,
  UserAddOutlined,
  FolderOutlined,
  ImportOutlined,
  PlusCircleOutlined,
} from '@ant-design/icons';
import '@/styles/Sidebar.css';
import Link from 'next/link';

const Sidebar = () => {
  const [collapsed, setCollapsed] = useState(false);

  const toggleSidebar = () => {
    setCollapsed(!collapsed);
  };

  return (
    <div className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
      <div className="sidebar-header">
        <h2 className="sidebar-logo">{collapsed ? 'W' : 'WORSIE'}</h2>
        <Button
          type="text"
          icon={collapsed ? '>' : '<'}
          onClick={toggleSidebar}
          className="toggle-button"
        />
      </div>
      <div className="sidebar-section">
        <ul>
          <li><HomeOutlined /><span className={collapsed ? 'hidden' : ''}> Home</span></li>
          <li><PlusCircleOutlined /><span className={collapsed ? 'hidden' : ''}> Create</span></li>
          <li><Link href='/Inbox'><InboxOutlined /><span className={collapsed ? 'hidden' : ''}> Inbox</span></Link></li>
          <li><ImportOutlined /><span className={collapsed ? 'hidden' : ''}> Import / Export</span></li>
          <li><FolderOutlined /><span className={collapsed ? 'hidden' : ''}> My Staff</span></li>
          <li><SettingOutlined /><span className={collapsed ? 'hidden' : ''}> Following</span></li>
          <li><UserAddOutlined /><span className={collapsed ? 'hidden' : ''}> User Management</span></li>
          <li><Link href='/AdvanceSearch'><SearchOutlined /><span className={collapsed ? 'hidden' : ''}> Advance Search</span></Link></li>
        </ul>
      </div>
      <div className="sidebar-section">
        <h4 className={`sidebar-title ${collapsed ? 'hidden' : ''}`}>Favorite</h4>
        <ul>
          <li><StarOutlined /><span className={collapsed ? 'hidden' : ''}> Marketing Team</span></li>
          <li><StarOutlined /><span className={collapsed ? 'hidden' : ''}> Production</span></li>
        </ul>
      </div>
      <div className="sidebar-section">
        <h4 className={`sidebar-title ${collapsed ? 'hidden' : ''}`}>Navigation</h4>
        <ul>
          <li><TeamOutlined /><span className={collapsed ? 'hidden' : ''}> Apple</span></li>
          <li><TeamOutlined /><span className={collapsed ? 'hidden' : ''}> Shell</span></li>
          <li><TeamOutlined /><span className={collapsed ? 'hidden' : ''}> Microsoft</span></li>
          <li><TeamOutlined /><span className={collapsed ? 'hidden' : ''}> Nestle</span></li>
        </ul>
      </div>
      <div className="sidebar-footer">
        <SettingOutlined /><span className={collapsed ? 'hidden' : ''}> Settings</span>
      </div>
    </div>
  );
};

export default Sidebar;
